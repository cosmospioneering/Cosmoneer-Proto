1> Copper weight & Layer thickness & material
     1oz copper.  Board thickness is .062"., FR4
 
2> Hole size tolerance and plating
     All holes are plated through, +/-003"(+/-0.08mm)

3> Soldermask tolerance & color
     .003"(0.075mm)  Color, blue
 
4> Plating & Leveling
     Hot Air Solder Level
 
5> Silkscreen side & color
     Top & Bottom silkscreen.  Color, White.
 
6> Dimensional size & tolerance
     70mm(2.756")  X  50mm(1.968"),  +/- 0.012"(0.3mm)
     Max radius on inside pcb corners is .070"
 
7> Electrical testing
     Electrical testing is not required

8> Inner layer isolated pads
    Isolated pads may be removed from inner layers.
 
9> Datecode & Mfg Marking
    Date Code and Mfg Code are not required.


